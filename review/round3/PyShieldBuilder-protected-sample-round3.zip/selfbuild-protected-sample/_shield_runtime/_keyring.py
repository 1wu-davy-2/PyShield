"""Generated per-build runtime key material.

Do not commit or reuse this file. The master key is split and XOR-masked so it
is not recoverable with a plain ``strings`` scan. This raises extraction cost;
it is not a confidentiality boundary.
"""

from __future__ import annotations

_MASK = bytes.fromhex("7ab94d6675e9cf67c16bdfffe51448aee06dbec9ff02531531a6631dc8d442dd")
_PARTS = (
    bytes.fromhex("71e7f60d"),
    bytes.fromhex("09504014"),
    bytes.fromhex("1daa0bab"),
    bytes.fromhex("eebee848"),
    bytes.fromhex("7685a31b"),
    bytes.fromhex("7733fc5e"),
    bytes.fromhex("778e891d"),
    bytes.fromhex("b6c1fb81"),
)


def master_key() -> bytes:
    material = b"".join(_PARTS)
    return bytes(
        value ^ _MASK[index % len(_MASK)]
        for index, value in enumerate(material)
    )
