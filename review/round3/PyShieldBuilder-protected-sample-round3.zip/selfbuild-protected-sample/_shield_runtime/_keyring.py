"""Generated per-build runtime key material.

Do not commit or reuse this file. The master key is split and XOR-masked so it
is not recoverable with a plain ``strings`` scan. This raises extraction cost;
it is not a confidentiality boundary.
"""

from __future__ import annotations

_MASK = bytes.fromhex("1c363df0c62a4aca7950e95e21f13c6d056d190dc8ec67d754561a13cbcf6a04")
_PARTS = (
    bytes.fromhex("d3d3f78e"),
    bytes.fromhex("a8d81cc7"),
    bytes.fromhex("43a00770"),
    bytes.fromhex("32c92e47"),
    bytes.fromhex("c3aa0f96"),
    bytes.fromhex("b81880c9"),
    bytes.fromhex("f479c532"),
    bytes.fromhex("89cf5afc"),
)


def master_key() -> bytes:
    material = b"".join(_PARTS)
    return bytes(
        value ^ _MASK[index % len(_MASK)]
        for index, value in enumerate(material)
    )
