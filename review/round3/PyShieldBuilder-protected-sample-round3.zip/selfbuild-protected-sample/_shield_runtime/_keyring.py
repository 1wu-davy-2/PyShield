"""Generated per-build runtime key material.

Do not commit or reuse this file. The master key is split and XOR-masked so it
is not recoverable with a plain ``strings`` scan. This raises extraction cost;
it is not a confidentiality boundary.
"""

from __future__ import annotations

_MASK = bytes.fromhex("b708e08a9db94ceaa9b7b7c00a80eb22a397288856ecfdfe32488bb683427892")
_PARTS = (
    bytes.fromhex("245d1380"),
    bytes.fromhex("80b6eeb5"),
    bytes.fromhex("0684864c"),
    bytes.fromhex("d416066f"),
    bytes.fromhex("7c86ea54"),
    bytes.fromhex("1d726acb"),
    bytes.fromhex("af29a2bb"),
    bytes.fromhex("662dc66b"),
)


def master_key() -> bytes:
    material = b"".join(_PARTS)
    return bytes(
        value ^ _MASK[index % len(_MASK)]
        for index, value in enumerate(material)
    )
