"""Generated per-build runtime key material.

Do not commit or reuse this file. The master key is split and XOR-masked so it
is not recoverable with a plain ``strings`` scan. This raises extraction cost;
it is not a confidentiality boundary.
"""

from __future__ import annotations

_MASK = bytes.fromhex("ba8f5781d6631ad14fe8c086bfbe67625876d6c28b58c9fe5660802a02a60d8c")
_PARTS = (
    bytes.fromhex("2756e566"),
    bytes.fromhex("3c2cb87d"),
    bytes.fromhex("ffd7120b"),
    bytes.fromhex("c5bd554b"),
    bytes.fromhex("0419ef52"),
    bytes.fromhex("8d3edd6a"),
    bytes.fromhex("3984e891"),
    bytes.fromhex("84519dd8"),
)


def master_key() -> bytes:
    material = b"".join(_PARTS)
    return bytes(
        value ^ _MASK[index % len(_MASK)]
        for index, value in enumerate(material)
    )
