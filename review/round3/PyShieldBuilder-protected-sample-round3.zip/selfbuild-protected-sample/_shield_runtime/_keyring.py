"""Generated per-build runtime key material.

Do not commit or reuse this file. The master key is split and XOR-masked so it
is not recoverable with a plain ``strings`` scan. This raises extraction cost;
it is not a confidentiality boundary.
"""

from __future__ import annotations

_MASK = bytes.fromhex("af8717162a564ad8379d2339fcf9d299b94c235e4e6096f717738d2005b89cf4")
_PARTS = (
    bytes.fromhex("e4d3b71f"),
    bytes.fromhex("ea460189"),
    bytes.fromhex("3717f620"),
    bytes.fromhex("da3c03aa"),
    bytes.fromhex("854938ca"),
    bytes.fromhex("3890a20e"),
    bytes.fromhex("4461cda9"),
    bytes.fromhex("e00a8d19"),
)


def master_key() -> bytes:
    material = b"".join(_PARTS)
    return bytes(
        value ^ _MASK[index % len(_MASK)]
        for index, value in enumerate(material)
    )
