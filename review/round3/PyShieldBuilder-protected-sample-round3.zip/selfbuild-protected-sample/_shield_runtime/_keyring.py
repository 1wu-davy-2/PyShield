"""Generated per-build runtime key material.

Do not commit or reuse this file. The master key is split and XOR-masked so it
is not recoverable with a plain ``strings`` scan. This raises extraction cost;
it is not a confidentiality boundary.
"""

from __future__ import annotations

_MASK = bytes.fromhex("fd455a8b03d146f3d501210a3024095b301a697655797fa224901937e100bf62")
_PARTS = (
    bytes.fromhex("af25df7b"),
    bytes.fromhex("964f7ca1"),
    bytes.fromhex("fd5b2821"),
    bytes.fromhex("7737d016"),
    bytes.fromhex("ba90c840"),
    bytes.fromhex("5d6437c5"),
    bytes.fromhex("589a3c58"),
    bytes.fromhex("c8f45114"),
)


def master_key() -> bytes:
    material = b"".join(_PARTS)
    return bytes(
        value ^ _MASK[index % len(_MASK)]
        for index, value in enumerate(material)
    )
