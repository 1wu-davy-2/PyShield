# Round 3 self-build sample notice (round-4 fixes)

This is the pre-PyInstaller protected tree produced by `tools/selfbuild.py --stage-only`.
It is a review artifact, not a release package and not a confidentiality boundary.

- build_id: `0617618bfb042369`
- protected business modules: 28
- runtime: `source` (intentionally plaintext so PyInstaller can analyze it)
- integrity: `off` for the self-protected exe
- build secret: removed
- master key: split and XOR-masked in `_shield_runtime/_keyring.py`; no single Base85 constant
- every `pyshield/*.py`, `gui/*.py` and `manage.py` is a PyShield stub

The same tree is used only as an intermediate product. A production build must not
ship this directory: it contains plaintext runtime code and reconstructable key material.
