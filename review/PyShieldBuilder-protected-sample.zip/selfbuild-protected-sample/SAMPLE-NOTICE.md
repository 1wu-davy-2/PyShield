# PyShieldBuilder 自保护样本（审查专用）

这是 `tools/selfbuild.py` 在 PyInstaller 打包**之前**生成的受保护源码树，用于让审查方直接检查“业务代码在进入 exe 之前已经被加密”这一事实。

- 源码版本：`develop @ 2b4e501`
- 生成时间：2026-11-14 20:29（本地时间）
- 生成命令：

  ```powershell
  python tools/selfbuild.py --stage-only --workdir <空的临时目录>
  ```

- 构建 ID：`33d9f7faed18a913`
- 受保护模块：27 个
- 文件数：43 个（不含本说明与校验脚本）

## 内容

| 路径 | 说明 |
|---|---|
| `pyshield/**/*.py` | 19 个业务模块的 stub，开头为 `# PyShield protected module...`，实际代码在 Base85 密文中 |
| `gui/**/*.py` | 7 个界面层模块的 stub |
| `manage.py` | 自保护入口 stub |
| `_shield_runtime/` | 运行时解密器源码（`runtime_source=True`，仅用于让 PyInstaller 做静态分析；最终 exe 中由 PyInstaller 编译成字节码） |
| `pyshield.lic` | 本样本的自用许可证，格式 3，不含 `build_key` |
| `.pyshield-build.json` | 构建元数据（build_id、cipher、modules 等） |
| `gui/web/`、`gui/assets/` | 界面静态资源，不属于 Python 业务代码 |

## 明确不含

- 原始明文 `pyshield/`、`gui/` 源码；
- 构建密钥 `*.shield-secret.json`；
- `runtime_template/`；
- `__pycache__`、`.pyc`、`.pyo`。

## 安全边界（请按此评估）

1. 这是**测试样本**，不是发布物。它包含本次测试构建的 master key（位于 `_shield_runtime/_core.py`）和自用许可证；这两者只能解密本样本，不能解密 `ci-develop-latest` 中的正式 exe。
2. 样本中的 `_shield_runtime/` 是明文运行时源码，原因是自保护构建需要 PyInstaller 能静态分析它；最终 onefile exe 中该运行时以编译后的字节码存在，不是以 `datas` 明文交付。
3. 即使业务模块在静态文件层面已加密，离线 exe 仍必须携带 master key 和许可证；具备调试能力的攻击者仍可在运行时取得明文。本方案的目标是**提高静态逆向成本**，不是保证“源码永不落地”。
4. 关闭了 manifest 完整性校验（`integrity: off`），因为 onefile 的 `_MEIPASS` 布局与默认清单扫描不一致；发布完整性目前依赖代码签名，后续需补 Authenticode。

请先运行 `python verify_sample.py` 做结构校验，再抽查任意 `pyshield/*.py` 的 stub。
